<?php
session_start();

if (!isset($_SESSION['documento'])) {
    header("Location:../index.html");
}
require '../ModeloDAO/UsuarioDao.php';
require '../ModeloDTO/UsuarioDto.php';
require '../Utilidades/conexion.php';

$uDao = new UsuarioDao();

$documento = $_SESSION['documento'];
$fecha = $_GET['fecha'] ?? null;
$curso = $_GET['gradoc'] ?? null;
$materia = $_GET['idmatc'] ?? null;


// Llamada al método para listar las asistencias del usuario logueado
$asistencias = $uDao->listarAsistenciasPorDocumento($fecha, $materia, $documento);
$curso = $uDao->Cursoper($_SESSION['documento']);
$u = $uDao->user($_SESSION['documento']);
$materias = $uDao->ListarMaterias();


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../STYLES/diseño.css">
    <link rel="stylesheet" href="../STYLES/asistencia.css">
    <title>GOE</title>
</head>
<body>
<div class="menu colordis">
        <div class="title">
            <h1>GOE</h1>
            <img src="../IMG/GOE.jpg" alt="">
        </div>

        <ul>
            <li><a href="home.php"><img src="../IMG/home.svg" alt=""><p>Home</p></a></li>
            <li><a href="observadores.php"><img src="../IMG/info.svg" alt=""><p>Observador</p></a></li>
            <li><a href="asistencia.php"><img src="../IMG/inbox.svg" alt=""><p>Asistencia</p></a></li>
            <li><a href="exit.php"><img src="../IMG/exit.svg" alt=""><p>Cerrar Sesion</p></a></li>
        </ul>
    </div> 

    <!-- nav -->

    <!--Contenido de la pagina-->
    <div class="contenido">

        <div class="container colordiv">
        <form method="GET" action="asistencia.php">
                <div class="uno">
                    <h3>Fecha</h3>
                    <input type="date" name="fecha">
                    <h3 style= "display:flex; flex-direction: row;" >Curso: <p>  <?php echo $u['grado'];?></p></h3>
                    
                    
                    <h3>Materia</h3>
                    <select name="idmatc" id="" class="select">
                    
                        <option value="">Selecciona una materia</option>
                        <?php
                            foreach ($materias as $index => $materia) { ?>
                                <option value="<?php echo $materia['idmat']; ?>"><?php echo $materia['nomb_mat']; ?></option>;
                            <?php }
                        ?>
                    </select>
                </div>
                
                <button type="submit" class="button" style=" margin: 10px 42%;">Buscar</button>
            </form>
            
            <h1>Asistencias</h1>
            <table id="user-table">
                <thead>
                    <tr>
                        <th>Materia</th>
                        <th>Profesor</th>
                        <th>Fecha Hora</th>
                        <th>Opcion</th>
                    </tr>
                </thead>
                <tbody>

                <?php
                    foreach ($asistencias as $index => $asistencia) { ?>
                        <tr>
                            <td><?php echo $asistencia['nomb_mat']; ?></td>
                            <td><?php echo $asistencia['profesor']; ?></td>
                            <td><?php echo $asistencia['fecha_asistencia']; ?></td>
                            <td><a href="#openModal" class="button" id="<?php echo $index; ?>" onclick="verObservation(<?php echo $index; ?>)">VER</a></td>
                        </tr>
                <?php }?>

                    <!-- Add more rows here as needed -->
                </tbody>
            </table>
            <!--div class="buttons">
                <button>Excel</button>
                <button>PDF</button>
            </div-->
        </div>
    </div>
</body>
</html>


<!-- modal para actualizar y ver la asistencia -->

<div id="openModal" class="modal_asis">
    <div class="colordiv">
        <a href="#close" id="close" class="close">X</a>
        <h2 style="text-align: center;">Listado de Asistencia</h2>
        <h3>Curso:  <?php echo $u['grado']; ?></h3>
        <h3>Materia: <h4 id="nomb_mat"></h4></h3>
        <h3>Fecha: <h4 id="fecha_asistencia"></h4></h3>
        <br>
        <form action="">
            <table id="user-table">
                <thead>
                    <tr>
                        <th>Profesor</th>
                        <th>Mi Documento</th>
                        <th>Estado</th>
                        <th>Justificacion</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td id="profesor"></td>
                        <td id="documento"></td>
                        <td id="estado_asis"></td>
                        <td id="justificacion_inasistencia"></td>
                    </tr>
            </table>
            <br>

        </form>
    </div>
</div>


<script>
    function verObservation(index) {
        // Obtener la lista de observaciones desde PHP (puedes pasarla al JS de alguna manera, por ejemplo, como un JSON en un input oculto)
        const asistencias = <?php echo json_encode($asistencias); ?>;
        
        // Buscar la observación que corresponde al índice
        const asistencia = asistencias[index];

        document.getElementById("profesor").innerText = asistencia.profesor;
        document.getElementById("documento").innerText = asistencia.documento;
        document.getElementById("estado_asis").innerText = asistencia.estado_asis;
        document.getElementById("nomb_mat").innerText = asistencia.nomb_mat;
        document.getElementById("fecha_asistencia").innerText = asistencia.fecha_asistencia;
        document.getElementById("justificacion_inasistencia").innerText = asistencia.justificacion_inasistencia;
    }
</script>



<!--https://layers.to/layers/clv0q7xjj005dky0hzjj7rhtb-->