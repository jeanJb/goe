<?php
include 'db.php';
$conn = get_db_connection();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $documento = $_POST['documento'];
    $profesor = $_POST['profesor'];
    $estado_asis = $_POST['estado_asis'];
    $IdMat = $_POST['IdMat'];
    $Fecha_asistencia = $_POST['Fecha_asistencia'];
    $justificacion_inasistencia = $_POST['justificacion_inasistencia'];

    $sql = "INSERT INTO asistencia (documento, profesor, estado_asis, IdMat, Fecha_asistencia, justificacion_inasistencia)
            VALUES ('$documento', '$profesor', '$estado_asis', '$IdMat', '$Fecha_asistencia', '$justificacion_inasistencia')";

    if ($conn->query($sql) === TRUE) {
        header('Location: index.php');
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar asistencia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Agregar nueva asistencia</h1>
        <form action="agregar_asistencia.php" method="POST">
            <div class="mb-3">
                <label for="documento" class="form-label">Documento</label>
                <input type="number" name="documento" class="form-control" required>
            </div>
            
            <div class="mb-3">
                <label for="profesor" class="form-label">profesor</label>
                <input type="text" name="profesor" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="estado_asis" class="form-label">Estado</label>
                <input type="text" name="estado_asis" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="IdMat" class="form-label">Materia ID</label>
                <input type="number" name="IdMat" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="Fecha_asistencia" class="form-label">Fecha de Asistencia</label>
                <input type="datetime-local" name="Fecha_asistencia" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="justificacion_inasistencia" class="form-label">Justificación</label>
                <input type="text" name="justificacion_inasistencia" class="form-control">
            </div>

            <button type="submit" class="btn btn-success">registrar asistencia</button>
        </form>
        <a href="index.php" class="btn btn-secondary mt-3">volver a la lista</a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
