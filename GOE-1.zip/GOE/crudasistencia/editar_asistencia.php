<?php
include 'db.php';
$conn = get_db_connection();

$idasistencia = $_GET['id'];
$sql = "SELECT * FROM asistencia WHERE idasistencia = '$idasistencia'";
$result = $conn->query($sql);
$attendance = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $estado_asis = $_POST['estado_asis'];
    $profesor = $_POST['profesor'];
    $Fecha_asistencia = $_POST['Fecha_asistencia'];
    $justificacion_inasistencia = $_POST['justificacion_inasistencia']; // Cambiado aquí

    // Verificar que la fecha no esté vacía antes de convertirla
    if (!empty($Fecha_asistencia)) {
        $timestamp = strtotime($Fecha_asistencia);
        // Puedes realizar más validaciones si es necesario
    } else {
        // Manejar el error o establecer un valor predeterminado
    }

    // Asegúrate de que las variables sean seguras para evitar SQL Injection
    $sql = "UPDATE asistencia 
            SET estado_asis = '$estado_asis', profesor = '$profesor', Fecha_asistencia = '$Fecha_asistencia', justificacion_inasistencia = '$justificacion_inasistencia' 
            WHERE idasistencia = '$idasistencia'";

    if ($conn->query($sql) === TRUE) {
        header('Location: index.php');
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar asistencia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Editar registro de asistencia</h1>
        <form action="editar_asistencia.php?id=<?php echo $idasistencia; ?>" method="POST">
            <div class="mb-3">
                <label for="estado_asis" class="form-label">Estado de Asistencia</label>
                <input type="text" name="estado_asis" class="form-control" value="<?php echo $attendance['estado_asis']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="profesor" class="form-label">Profesor</label>
                <input type="text" name="profesor" class="form-control" value="<?php echo $attendance['profesor']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="Fecha_asistencia" class="form-label">Fecha de Asistencia</label>
                <input type="datetime-local" name="fecha_asistencia" class="form-control" value="<?php echo date('Y-m-d\TH:i', strtotime($attendance['fecha_asistencia'])); ?>" required>
            </div>

            <div class="mb-3">
                <label for="justificacion_inasistencia" class="form-label">Justificación de Inasistencia</label>
                <input type="text" name="justificacion_inasistencia" class="form-control" value="<?php echo $attendance['justificacion_inasistencia']; ?>">
            </div>

            <button type="submit" class="btn btn-success">Actualizar registro</button>
        </form>
        <a href="index.php" class="btn btn-secondary mt-3">Volver a la lista</a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
