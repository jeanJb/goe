<?php
include 'db.php';
$conn = get_db_connection();

$idasistencia = $_GET['id'];
$sql = "DELETE FROM asistencia WHERE idasistencia = '$idasistencia'";

if ($conn->query($sql) === TRUE) {
    header('Location: index.php');
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
