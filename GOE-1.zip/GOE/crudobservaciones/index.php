<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/dashboard.css">
     <link rel="stylesheet" href="css/diseño.css">
    <link rel="stylesheet" href="css/home.css">
    
    
    <title>Registro observador </title>
</head>

<DIv>
<body class="container m-0 row justify-content-center">
    <div>
<div class="menu colordis">
        <div class="title">
            <h1>GOE</h1>
            <img src="IMG/GOE.jpg" alt="">
        </div>

        <ul>
            <li><a href="home.html"><img src="IMG/home.svg" alt=""><p>Home</p></a></li>
            <li><a href="observadores.html"><img src="IMG/info.svg" alt=""><p>Observador</p></a></li>
            <li><a href="asistencia.html"><img src="IMG/inbox.svg" alt=""><p>Asistencia</p></a></li>
            <li><a href="login.html"><img src="IMG/user.svg" alt=""><p>Login</p></a></li>

        </ul>
    </div>
 </div>
</div>
 <div>
 <div class="col-18 col-md-8">
    <div class="row mt-5 justify-content-center">
    <div class="col-6">
                <img src="img/ctjfr.jpeg" class="title" width="200" alt="">
                    </div>
                </div>
            </div>

        </div>
    <div class="col-12 col-md-4">
    <div class="row mt-5 justify-content-center">
    <div class="col-6">
            <h1 class="text-center">OBSERVACIONES</h1>
            </div>
            <div class="row justify-content-center">
                <a href="registro.php" class="btn btn-primary btn-md btn-block mb-2 ">REGISTRAR OBSERVACION</a>
                <a href="listado.php" class="btn btn-info btn-md btn-block">REPORTE</a>
            </div>
        </div>
    </div>
    </div>
    
  

</body>

</html>