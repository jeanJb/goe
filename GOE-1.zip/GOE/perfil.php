<?php
session_start();

if (!isset($_SESSION['documento'])) {
    header("Location:../index.html");
}
require 'ModeloDAO/UsuarioDao.php';
require 'ModeloDTO/UsuarioDto.php';
require 'Utilidades/conexion.php';

$uDao = new UsuarioDao();

// Llamada al método para listar las observaciones del usuario logueado
$user = $uDao->listarUsuariosper($_SESSION['documento']);
$curso = $uDao->Cursoper($_SESSION['documento']);
$usuario = $uDao->obtenerUsuario($_SESSION['documento']);
$u = $uDao->user($_SESSION['documento']);


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="STYLES/diseño.css">
    <link rel="stylesheet" href="STYLES/perfil.css">
    <title>GOE</title>
</head>
<body>
<div class="menu colordis">
        <div class="title">
            <h1>GOE</h1>
            <img src="IMG/GOE.jpg" alt="">
        </div>

        <ul>
            <li><a href="home.php"><img src="IMG/home.svg" alt=""><p>Home</p></a></li>
            <li><a href="observadores.php"><img src="IMG/info.svg" alt=""><p>Observador</p></a></li>
            <li><a href="asistencia.php"><img src="IMG/inbox.svg" alt=""><p>Asistencia</p></a></li>
            <li><a href="intro.php"><img src="IMG/user.svg" alt=""><p>Login</p></a></li>
        </ul>
    </div> 

    <!-- nav -->

    <nav class="nav colordis">
    <h1 style="float: left; margin: 12px 0 10px 10px;"><?php echo $u['nombre1']; ?> <?php echo $u['apellido1']; ?></h1>
        <ul>
            <li><a href="alert.html"><img src="IMG/message-circle.svg" alt=""><!-- <p>Notificaciones</p> --></a></li>
            <li><a href="perfil.php"><img src="IMG/user.svg" alt="" style="border: 1px #50c6e3 solid;"><!-- <p>Perfil</p> --></a></li>
            <li><a href="exit.php"><img src="IMG/exit.svg" alt=""><!-- <p>Cerrar Sesion</p> --></a></li>
        </ul>
    </nav>

    <!--Contenido de la pagina-->
    <?php
        foreach ($user as $us) { ?>
    <div class="contenido">
        <div class="perfil colordiv">
            <div class="pp">
                <div class="img">
                    <img src="../IMG/user.svg" alt="">
                </div>
                <center><h2><?php echo $usuario['nombre1']; ?> <?php echo $usuario['apellido1']; ?></h2></center>
                <center><h3 style="margin-bottom: 8px;"><?php echo $usuario['nom_rol']; ?></h3></center>
                <center><h3>CURSO:   <?php echo $usuario['grado']; ?></h3></center>
                <br>
                <center><a href="#openModal" class="button">ACTUALIZAR PERFIL</a></center>
            </div>
            <!--h6>Nombre:</!--h6>
            <h3>Jean Paul Martinez</h3>
            <br-->
            <div style="width: 35%; float: left;">
                <h1>Datos Adicionales</h1>
                <br>
                <h3>Documento:</h3>
                <h4><?php echo $us['documento']; ?></h4>
                <br>
                <h3>Email:</h3>
                <h4><?php echo $us['email']; ?></h4>
                <br>
                <h3>Telefono:</h3>
                <h4><?php echo $us['telefono']; ?></h4>
                <br>
                <h3>Direccion:</h3>
                <h4><?php echo $us['direccion']; ?></h4>
            </div>

        </div>

        <?php } ?>

            
            <!--div style="float: right; width: 35%;">
                <center><h2>Horarios de Atención a Padres</h2></center>
                <br>
                <h3>Lunes a Viernes</h3>
                <br>
                <h4>Mañana: 10:00 AM - 11:00 AM</h4>
                <h4>Tarde: 4:00 PM - 5:00 PM</h4>
            </!--div-->
        
        <div class="materia colordiv">
            <h1>MATERIAS</h1>
            <br>
            <h3>ciencias</h3>
            <h3>quimica</h3>
            <h3>fisica</>
        </div>
        <div class="cursos colordiv"></div>
    </div>
</div>
</body>
</html>

<!-- Modal para actualizar perfil -->

<!-- <div id="openModal" class="modal_asis">
    <div class="colordiv">
        <a href="#close" id="close" class="close">X</a>
        <h2 style="text-align: center;">Actualizar Perfil</h2>
        <br>
        <form action="">
            <br>
            <h3>Documento:</h3>
            <input type="number" name="" id="" readonly>

            <br>
            <h3>ROL:</h3>
            <input type="text" name="" id="" readonly>

            <br>
            <h3>Email:</h3>
            <input type="email" name="" id=""required>
            
            <br>
            <h3>Contraseña:</h3>
            <input type="password" name="" id="" required>

            <br>
            <h3>Tipo Documento:</h3>
            <Select class="select" readonly>
                <option value="">T.I</option>
                <option value="">C.C</option>
                <option value="">C.E</option>
            </Select>

            <br>
            <h3>Primer Nombre:</h3>
            <input type="number" name="" id="">

            <br>
            <h3>Segundo Nombre:</h3>
            <input type="text" name="" id="">

            <br>
            <h3>Primer Apellido:</h3>
            <input type="text" name="" id="">

            <br>
            <h3>Segundo Apellido:</h3>
            <input type="text" name="" id="">

            <br>
            <h3>Telefono:</h3>
            <input type="number" name="" min="10" max="10" id="">

            <br>
            <h3>Direccion:</h3>
            <h4></h4>

            <br>
            <h3>Foto:</h3>
            <input type="file" name="" id="">
            <br>

            <button class="button" type="submit">ACTUALIZAR</button>
        </form>
    </div>
</div> -->

<!--https://layers.to/layers/clv0q7xjj005dky0hzjj7rhtb-->